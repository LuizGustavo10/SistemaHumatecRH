<ul class="menu">
    <li>
        <h5 style="text-align: center; color: white;"> 
        <i class="fa-solid fa-user"></i> Bem vindo(a) <?php echo $_SESSION['usuario']; ?>
        </h5>
     </li>

    <li> <a href="./sistema.php" class="menu-item"> Usuário </a> </li>
    <li> <a href="./cidade.php" class="menu-item"> Cidade </a> </li>
    <li> <a href="./escola.php" class="menu-item"> Escola </a> </li>
    <li> <a href="./cardapio.php" class="menu-item"> Cardápio </a> </li>
    <li> <a href="./sair.php" class="menu-item"> Sair </a> </li>
</ul>